var data_location = 'iris.data'
var iris_data;
d3.csv(data_location).then(function(data){
  data.forEach(function(d){
    d.sepal_length = +d.sepal_length;
    d.sepal_width = +d.sepal_width;
    d.petal_length = +d.petal_length;
    d.petal_width = +d.petal_width;
  });
  iris_data = data;
  console.log(iris_data);
  draw_scatterpoints();
  assign_brush_events();
});
const padding = 25
const scatterplot_size = 400
const scatterpoint_radius = 6
const svg_width = scatterplot_size * 2 + padding * 4
const svg_height = scatterplot_size + padding * 4
var svg = d3.select('#svg_chart').append('svg')
  .attr('width', svg_width)
  .attr('height', svg_height);


svg.append('rect')
  .attr('fill', 'none')
  .attr('stroke', 'black')
  .attr('x', padding)
  .attr('y', padding)
  
  .attr('width', scatterplot_size)
  .attr('height', scatterplot_size);

svg.append('rect')
  .attr('fill', 'none')
  .attr('stroke', 'black')
  .attr('x', scatterplot_size + padding * 3)
  .attr('y', padding)
  .attr('width', scatterplot_size)
  .attr('height', scatterplot_size);


var sepal_length_scale = d3.scaleLinear()
  .range([scatterpoint_radius, scatterplot_size-scatterpoint_radius])
  .domain([4.3, 7.9]);

    


var sepal_width_scale = d3.scaleLinear()
  .range([scatterpoint_radius, scatterplot_size-scatterpoint_radius])
  .domain([2.0, 4.4]);

var sepal_scatterplot = svg.append('g')
  .attr('class', 'sepal_group')
  .attr('transform', `translate(${padding},${padding})`);

var petal_length_scale = d3.scaleLinear()
  .range([scatterpoint_radius, scatterplot_size-scatterpoint_radius])
  .domain([1.0, 6.9]);
 

var petal_width_scale = d3.scaleLinear()
  .range([scatterpoint_radius, scatterplot_size-scatterpoint_radius])
  .domain([0.1, 2.5]);
var class_color = d3.scaleOrdinal(d3.schemeTableau10)

var petal_scatterplot = svg.append('g')
  .attr('class', 'petal_group')
  .attr('transform', `translate(${scatterplot_size + padding * 3},${padding})`);

// make scatterplot point groups



petal_scatterplot.append("g").attr("transform", "translate(10,400)").call(d3.axisBottom(petal_length_scale).ticks(7, d3.format(".1f")));
petal_scatterplot .append("g").attr("transform", "translate(0,5)").call(d3.axisLeft(petal_width_scale).ticks(7, d3.format(".1f")));
sepal_scatterplot.append("g").attr("transform", "translate(10,400)").call(d3.axisBottom(sepal_length_scale).ticks(7, d3.format(".1f")));
sepal_scatterplot .append("g").attr("transform", "translate(0,5)").call(d3.axisLeft(sepal_width_scale).ticks(7, d3.format(".1f")));
  
function draw_scatterpoints(){
  //TODO: Finish drawing scatterplots by adding legends and axis.

  //TODO: append points to the scatterplot.
   var petal_points = petal_scatterplot.append('g').selectAll('circle').data(iris_data)
              .enter().append("circle")
              .attr("cx", d => petal_length_scale(d.petal_length))
              .attr("cy", d => petal_width_scale(d.petal_width))
              .attr("r", scatterpoint_radius)
              .attr("fill", d => class_color(d.class))

  var sepal_points = sepal_scatterplot.append('g').selectAll('circle').data(iris_data)
              .enter().append("circle")
							.attr("cx", d => sepal_length_scale(d.sepal_length))
							.attr("cy", d => sepal_width_scale(d.sepal_width))
              .attr("r", scatterpoint_radius)
              .attr("fill", d => class_color(d.class))
}

function assign_brush_events(){
  var sepal_points = sepal_scatterplot.selectAll('circle');
  var petal_points = petal_scatterplot.selectAll('circle');
  var circles = svg.selectAll('circle');
  var brush = d3.brush()
    .extent([[0, 0], [scatterplot_size, scatterplot_size]])
    .on('start', brushstarted)
    .on('brush', brushed)
    .on('end', brushend);
  sepal_scatterplot.call(brush);
  petal_scatterplot.call(brush);

  var selecting_scatterplot;

  
  function brushstarted()
  {
    if (selecting_scatterplot !== this) {
     d3.select(selecting_scatterplot).call(brush.move, null);
     selecting_scatterplot = this;
   }
   }

  function brushed(){
     if (d3.event.selection === null) return;
     var [[x0, y0], [x1, y1]] = d3.event.selection;
     circles.classed("deselected", d => {
      return x0 > sepal_length_scale(d.sepal_length)
          || x1 < sepal_length_scale(d.sepal_length)
          || y0 > sepal_width_scale(d.sepal_width)
          || y1 < sepal_width_scale(d.sepal_width);
    });
  }

  function brushend(){
    if (d3.event.selection !== null) return;
    circles.classed("deselected", false);
  }
}

